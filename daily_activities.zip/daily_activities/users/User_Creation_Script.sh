#!/bin/ksh
#
#  Paramaters
#  1.  database
#  2.  username
#  3.  Output file
#
if [[ $1 = "" ]] then
   echo 'Oracle Sid must be provided as parameter'
   exit
fi

if [[ $2 = "" ]] then
   echo 'User name must be provided as parameter'
   exit
fi

if [[ $3 = "" ]] then
   echo 'Output File must be provided as parameter'
   exit
fi

export ORACLE_SID=$1
export UserName=$2
export filename=$3
export ORAENV_ASK=NO

oraenv_file=`which oraenv | awk '{print $1}'`

. $oraenv_file
sqlplus /nolog <<EOF
conn /as sysdba;
set lines 140;
set long 100000;
set heading off;
set feedback off;
set echo off;
set termout off;
spool /tmp/userscript.txt;
exec dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'PRETTY',true);
exec dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'SQLTERMINATOR',true);
select (case
        when ((select count(*)
               from   dba_users
               where  username = '$UserName') > 0)
        then  dbms_metadata.get_ddl ('USER', '$UserName')
        else  to_clob ('   -- User is not Present into Database')
        end ) Extracted_DDL from dual
UNION ALL
select (case
        when ((select count(*)
               from   dba_ts_quotas
               where  username = '$UserName') > 0)
        then  dbms_metadata.get_granted_ddl( 'TABLESPACE_QUOTA', '$UserName')
        else  to_clob ('   -- No TS Quotas given for user !!!!!')
        end ) from dual
UNION ALL
select (case
        when ((select count(*)
               from   dba_role_privs
               where  grantee = '$UserName') > 0)
        then  dbms_metadata.get_granted_ddl ('ROLE_GRANT', '$UserName')
        else  to_clob ('   -- No Roles granted for user !!!!!')
        end ) from dual
UNION ALL
select (case
        when ((select count(*)
               from   dba_sys_privs
               where  grantee = '$UserName') > 0)
        then  dbms_metadata.get_granted_ddl ('SYSTEM_GRANT', '$UserName')
        else  to_clob ('   -- No System Privileges granted for user !!!!!')
        end ) from dual
UNION ALL
select (case
        when ((select count(*)
               from   dba_tab_privs
               where  grantee = '$UserName') > 0)
        then  dbms_metadata.get_granted_ddl ('OBJECT_GRANT', '$UserName')
        else  to_clob ('   -- No Object Privileges granted for user !!!!!')
        end ) from dual;

spool off;
exit;
EOF
sed '1,42d' /tmp/userscript.txt | sed  '/SQL/d' > $filename
rm /tmp/userscript.txt
