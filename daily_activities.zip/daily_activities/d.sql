set lines 200

set pages 999

set echo on

set serveroutput on


spool 00-pretask.log



@?/rdbms/admin/utlrp.sql


select owner, object_name, object_type from dba_objects where status <> 'VALID' order by 1,2;


select owner, index_name, table_name, status from dba_indexes where status not in ('VALID','N/A');



select index_owner, index_name, status from dba_ind_partitions where status not in ('USABLE','N/A');



spool off;




set lines 200

set pages 999

set echo on

set serveroutput on


spool 99-posttask.log



@?/rdbms/admin/utlrp.sql


select owner, object_name, object_type from dba_objects where status <> 'VALID' order by 1,2;


select owner, index_name, table_name, status from dba_indexes where status not in ('VALID','N/A');



select index_owner, index_name, status from dba_ind_partitions where status not in ('USABLE','N/A');



spool off;

