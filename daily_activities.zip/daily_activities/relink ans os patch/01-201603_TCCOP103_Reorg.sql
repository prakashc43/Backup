set lines 200
set pages 999
set timing on
set echo on

alter session set db_file_multiblock_read_count=128;
alter session set workarea_size_policy='MANUAL';
alter session set sort_area_size=800000000;
alter session enable parallel ddl;

spool 01-201603_TCCOP103_Reorg.log;


alter table BCPREPROC.AFFILIATION_PAYMENT_DTL move parallel 32;
alter table TC51USER.CS_TRANSACTIONADDRESS   move parallel 32;



spool off;

EXIT;
