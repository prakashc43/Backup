
set heading off
set feedback off
set serveroutput on
set lines 190
set pages 0
set newpage 0

-----------------------------------------------------------------------------------------------
-- SEGMENT ADVISOR SCRIPT TO BE RUN
-----------------------------------------------------------------------------------------------
spool temporario.sql

exec dbms_output.put_line('spool advisor.log');
exec dbms_output.put_line('execute dbms_advisor.delete_task(''SEGMENTADV_MANUAL'')');
exec dbms_output.put_line('var Id number;');
exec dbms_output.put_line('DECLARE ');
exec dbms_output.put_line('  Task_Name varchar2(100);');
exec dbms_output.put_line('  taskdesc varchar2(128);');
exec dbms_output.put_line('  task_id number;');
exec dbms_output.put_line('  object_id number;');
exec dbms_output.put_line('  numDaysToRetain varchar2(25);');
exec dbms_output.put_line('BEGIN');
exec dbms_output.put_line('  Task_Name := ''SEGMENTADV_MANUAL'';');
exec dbms_output.put_line('  taskdesc :=''Get shrink advice based on object growth trend'';');
exec dbms_output.put_line('  numDaysToRetain :=''30'';');
exec dbms_output.put_line('  dbms_advisor.create_task(Advisor_Name => ''Segment Advisor'', Task_Id => :Id, Task_Name => Task_Name, Task_Desc => TaskDesc);');



Select 'dbms_advisor.create_object(Task_Name, '''||REPLACE(segment_type,'LOBSEGMENT','LOB')||''','''||owner||''','''||segment_name||''','''||nvl(partition_name, ' ')||''', NULL, object_id);'
From Dba_segments
Where owner in (select distinct(owner) from dba_segments where bytes > 0 and owner not in ('SYS',
		'SYSTEM',
		'DBSNMP',
		'OUTLN',
		'MDSYS',
		'ORDSYS',
		'ORDPLUGINS',
		'CTXSYS',
		'DSSYS',
		'PERFSTAT',
		'WKPROXY',
		'WKSYS',
		'XDB',
		'ODM',
		'ODM_MTR',
		'OLAPSYS',
		'TRACESVR',
		'REPADMINAURORA$ORB$UNAUTHENTICATED',
		'AURORA$JIS$UTILITY$',
		'OSE$HTTP$ADMIN',
		'SCOTT',
		'HR',
		'OE',
		'PM',
		'SH',
		'QS',
		'QS_ES',
		'QS_WS',
		'QS_OS',
		'QS_CB',
		'QS_CS',
		'QS_ADM',
		'QS_CBADM',
		'ORABACK',
		'DATAPOINT',
		'CTLCTR_APP_USER',
		'SECURITY_AUDIT',
		'SYSMAN',
		'ORACLE_OCM',
		'TSMSYS',
		'DATAPOINT_AUDIT',
		'DATAPOINT_EM'))
      And segment_type In ('TABLE','INDEX','TABLE PARTITION','INDEX PARTITION','LOBSEGMENT')
	  and segment_name not like 'BIN$%'
Order By segment_type, segment_name;


exec dbms_output.put_line('  dbms_advisor.set_task_parameter(Task_Name => Task_Name, Parameter => ''recommend_all'', Value => ''TRUE'');');
exec dbms_output.put_line('  dbms_advisor.set_task_parameter(Task_Name, ''DAYS_TO_EXPIRE'', numDaysToRetain);');
exec dbms_output.put_line('END;');
exec dbms_output.put_line('/');


exec dbms_output.put_line('DECLARE ');
exec dbms_output.put_line('  Task_Name varchar2(100);');
exec dbms_output.put_line('BEGIN');
exec dbms_output.put_line('  Task_Name := ''SEGMENTADV_MANUAL'';');
exec dbms_output.put_line('  dbms_advisor.reset_task(Task_Name);');
exec dbms_output.put_line('  dbms_advisor.execute_task(Task_Name);');
exec dbms_output.put_line('END;');
exec dbms_output.put_line('/');
exec dbms_output.put_line('spool off;');

spool off;

-----------------------------------------------------------------------------------------------
-- RUN SEGMENT ADVISOR
-----------------------------------------------------------------------------------------------

@temporario.sql
exit;
