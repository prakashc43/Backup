set line 300
set line 300
Select Segment_Owner,
       Segment_Name,
       Segment_Type,
       Partition_Name,
       Sum(Round(Allocated_Space / 1024 / 1024, 2)) Allocated_Space,
       Sum(Round(Used_Space / 1024 / 1024, 2)) Used_Space,
       Sum(Round(Reclaimable_Space / 1024 / 1024, 2)) Reclaimable_Space
  From Table(Dbms_Space.Asa_Recommendations('TRUE', 'TRUE', 'FALSE')) Asa,
       (Select Distinct Task_Id
          From Dba_Advisor_Findings
         Where Task_Name = 'SEGMENTADV_MANUAL') Find
Where Asa.Task_Id = Find.Task_Id
Group By Segment_Owner, Segment_Name, Segment_Type, Partition_Name
Having(Sum(Round(Reclaimable_Space / 1024 / 1024, 2)) > 1024 OR
	  ((Sum(Round(Reclaimable_Space / 1024 / 1024, 2)) > Sum(Round(Allocated_Space / 1024 / 1024, 2))*0.9)
	   AND Sum(Round(Reclaimable_Space / 1024 / 1024, 2)) > 300))
Order By 1;
